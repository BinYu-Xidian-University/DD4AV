## News

SVF_CON:
- modified:   include/Graphs/PAG.h
- modified:   lib/Graphs/PAG.cpp
- modified:   lib/MSSA/MemSSA.cpp
- modified:   lib/MemoryModel/PointerAnalysis.cpp

based on 
```
commit 097e495a6ddb8771a51228606cad2c1e56b2cb6e
Author: yuleisui <rockysui@gmail.com>
Date:   Tue Aug 11 19:21:24 2020 +1000

    Fix PAGNode::hasValue()
```


Lastest Update for SVF commit: 0afd009810746433f7cd8c6ca27d5d8f5395b306

Difference in new version
```
wpa: Unknown command line argument '-indCallLimit=100000'.  Try: 'wpa --help'
wpa: Did you mean '--ind-call-limit=100000'?
```
