#!/bin/bash -e

URL="http://dolphin.kaist.ac.kr:56741"

wget $URL/mapping
wget $URL/mempair
wget $URL/mutation
wget $URL/p2
wget $URL/firstmapping
wget $URL/firstmempair
